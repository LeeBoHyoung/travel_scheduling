#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>
#include <string.h>
#include <time.h>

#define BUFSIZE 100

typedef struct trans { //graph weight
	int dist; //50 - 200 random select
	int cost; //dist * 100
	int travel_time; // dist / 50 
}trans;


typedef struct hotel* hotel_p;
typedef struct hotel {
	hotel_p left; //Left child within RB tree.
	hotel_p right; //Right child within RB tree.
	hotel_p parent; //Parent within RB tree.
	hotel_p nil;
	char clr; // r,b color

	char name[BUFSIZE];
	int cost; //50 - 300 random select �� * 1000

}hotel;

typedef struct site* site_p;
typedef struct site {
	char name[BUFSIZE];
	int stay_time; //4~10 random select
	int cost; // travel cost -> stay_time *  10000
	trans linked_transes; //Transportations which connect this site to other sites. graph edge weight

	site_p edge_link; // edge(trans) info
	hotel_p head; // link to hotel tree root
}site;

typedef struct map {
	hotel hotels[100];
}map;

typedef struct reservation* reserve_p;
typedef struct reservation{
	reserve_p left; //Left child within RB tree.
	reserve_p right; //Right child within RB tree.
	reserve_p parent; //Parent within RB tree.
	reserve_p nil;
	char clr;
	//site *route; //From the start site, trans, site, trans, site, ..., destination site.
	char id[BUFSIZE];
	int dist;
	int cost;
	int period;
}reservation;


//***functions***

//graph
void make_graph();
void add_vertex(site_p*, char*);
void add_edge(site_p, site_p, trans);
int index_vertex(site_p*, char*);
void DFS(char*); 
void DFS_route(char*, char*);

//hotel
void make_hotel();
void RB_INSERT(hotel_p*, char*, int);
void insert_fixup(hotel_p*, hotel_p);
void Right_Rotate(hotel_p*, hotel_p);
void Left_Rotate(hotel_p*, hotel_p);
void create_nilnode(hotel_p*);
void inorder(hotel_p);

//reservation
void Reserve_INSERT(reserve_p*, char*, int, int, int);
void r_insert_fixup(reserve_p*, reserve_p);
void r_Right_Rotate(reserve_p*, reserve_p);
void r_Left_Rotate(reserve_p*, reserve_p);
void r_create_nilnode(reserve_p*);
void Reserve_DELETE(reserve_p*, char*);
void r_inorder(reserve_p);
