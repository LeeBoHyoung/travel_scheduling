#define _CRT_SECURE_NO_WARNINGS
#include "final.h"

site_p site_Graph[100] = { 0 };
int Visited[100] = { 0 };
char stack[500][10] = { '0' }; top = -1, r = 0;
char site_route[500][500]; //������ ����
hotel_p* h_T; //hotel Tree�� root�� �ޱ�����

void add_vertex(site_p* arr, char* site_name) {
	srand(time(NULL));
	int stay = rand() % 6 + 5; // ü���ð��� 4�ð�~10�ð� ���� ���� ����
	int i = 0;
	site_p newnode = (site_p)malloc(sizeof(site));
	strcpy(newnode->name, site_name);
	newnode->stay_time = stay;
	newnode->cost = stay * 10000; // �������� ����ð� * 10000
	newnode->head = (*h_T);
	newnode->linked_transes.cost = 0;
	newnode->linked_transes.dist = 0;
	newnode->linked_transes.travel_time = 0;
	
	newnode->edge_link = NULL;
	if (*arr == NULL)
		*arr = newnode;
	else {
		while (arr[i] != 0) {
			if (strcmp(arr[i]->name, site_name)==0)
				return;
			i++;
		}
		arr[i] = newnode;
	}
}

//site �� ����, �׷��� edge�� weight�� trans ����
void add_edge(site_p v1, site_p v2, trans weight) {
	site_p new = (site_p)malloc(sizeof(site));
	strcpy(new->name, v2->name);
	new->cost = v2->cost;
	new->stay_time = v2->stay_time;
	new->head = v2->head;

	new->linked_transes = weight;

	new->edge_link = NULL;
	if (v1->edge_link == NULL)
		v1->edge_link = new;
	else {
		site_p temp = v1;
		while (temp->edge_link != NULL)
			temp = temp->edge_link;
		temp->edge_link = new;
	}
}

int index_vertex(site_p* arr, char *site_name) {
	int i = 0;
	while (strcmp(arr[i]->name, site_name)!=0)
		i++;
	return i;
}

void DFS(char* vertex) {
	int v = index_vertex(site_Graph, vertex);
	site_p w;
	Visited[v] = 1;
	printf("%s", vertex);
	for (w = site_Graph[v]; w; w = w->edge_link) {
		int temp = index_vertex(site_Graph, w->name);
		if (Visited[temp] == 0) {
			printf("[%d] ", w->linked_transes.dist);
			DFS(w->name);
		}
	}
}

/*void DFS_route(char* v, char* goal) {
	int v_index = index_vertex(site_Graph, v); int idx = 0;
	site_p w = site_Graph[v_index];
	Visited[v_index] = 1;
	strcpy(stack[++top], v);

	if (strcmp(v, goal)==0) { 
		for (int i = 0; i <= top; i++) {
			for (int j = 0; stack[i][j] != '\0'; j++) {
				site_route[r][idx++] = stack[i][j];
			}
			site_route[r][idx++] = ' ';
		}
		site_route[r][idx] = '\0';
		idx = 0;
		top--; r++;
		return;
	}

	while (w != NULL) {
		int temp = index_vertex(site_Graph, w->name);
		if (Visited[temp] == 0) {
			DFS_route(w->name, goal);
			Visited[temp] = 0;
		}
		w = w->edge_link;
	}
	top--;
}*/

void make_graph() {
	srand(time(NULL));
	char site_name[10]; strcpy(site_name, "site-");
	//�׷��� vertex ����, site-1 ~ site-100
	for (int i = 1; i <= 100; i++) {
		int j = 0;
		char num[10];
		_itoa(i, num, 10);
		for (j = 0; num[j] != '\0'; j++) {
			site_name[j + 5] = num[j]; // ex) site-1, site-78
		}
		site_name[j + 5] = '\0';
		add_vertex(site_Graph, site_name);
	}


	// site �� edge(trans) ����
	int site_1, site_2; trans trans_info;
	for (int i = 0; i < 300; i++) {
		// site �� ���� �������� ����
		site_1 = rand() % 100;
		site_2 = rand() % 100;

		while (1) {
			if (site_1 != site_2)
				break;
			else
				site_2 = rand() % 100;
		}

		//trans�� �������� ����
		trans_info.dist = rand() % 150 + 51; //50~200 ���� ���� ����
		trans_info.cost = trans_info.dist * 100;
		trans_info.travel_time = trans_info.dist / 50;

		add_edge(site_Graph[site_1], site_Graph[site_2], trans_info);
	}
}


